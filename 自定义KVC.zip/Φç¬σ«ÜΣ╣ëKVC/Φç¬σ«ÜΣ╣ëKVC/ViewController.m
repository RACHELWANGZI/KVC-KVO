//
//  ViewController.m
//  自定义KVC
//
//  Created by wangleilei on 2020/10/26.
//  Copyright © 2020 wangCompany. All rights reserved.
//

#import "ViewController.h"
#import "Person.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    Person *person = [[Person alloc] init];
}


@end
