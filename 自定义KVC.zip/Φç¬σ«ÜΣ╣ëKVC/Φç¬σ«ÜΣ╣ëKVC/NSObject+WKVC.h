//
//  NSObject+WKVC.h
//  自定义KVC
//
//  Created by wangleilei on 2020/10/26.
//  Copyright © 2020 wangCompany. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (WKVC)
//set
- (void)wl_setValue:(id)value forKey:(NSString *)key;
//get
- (id)wlValueForKey:(id)key;
@end

NS_ASSUME_NONNULL_END
