//
//  Person.m
//  自定义KVC
//
//  Created by wangleilei on 2020/10/26.
//  Copyright © 2020 wangCompany. All rights reserved.
//

#import "Person.h"

@implementation Person

+ (BOOL)accessInstanceVariablesDirectly{
    return NO;
}

- (void)setName:(NSString *)name{
    NSLog(@"%s - %@",__func__,name);
}

- (void)_setName:(NSString *)name{
    NSLog(@"%s - %@",__func__,name);
}

- (void)setIsName:(NSString *)name{
    NSLog(@"%s - %@",__func__,name);
}
@end
