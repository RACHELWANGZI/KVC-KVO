//
//  ViewController.h
//  自定义KVC
//
//  Created by wangleilei on 2020/10/26.
//  Copyright © 2020 wangCompany. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

