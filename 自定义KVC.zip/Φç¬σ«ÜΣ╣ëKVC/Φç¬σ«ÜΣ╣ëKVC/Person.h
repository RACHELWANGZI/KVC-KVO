//
//  Person.h
//  自定义KVC
//
//  Created by wangleilei on 2020/10/26.
//  Copyright © 2020 wangCompany. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject{
@public
   NSString *_isName;
   NSString *name;
   NSString *isName;
   NSString *_name;
}
@end

NS_ASSUME_NONNULL_END
